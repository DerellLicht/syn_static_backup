Command plugin for SynWrite.
It creates backup of current save file, with same name as original,
stored in specified backup directory.

How to install:
Open zip-file in SynWrite, and confirm installation.
Hotkey can be changed - see SynWrite FAQ about this. 

Authors: Daniel Miller
License: MIT
